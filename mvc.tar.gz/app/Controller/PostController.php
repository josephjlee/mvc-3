<?php

namespace App\Controller;
use Core\Controller;

class PostController extends Controller
{

    public function index(){
        $postsObject = new \App\Model\PostsModel();
        $this->view->posts = $postsObject->getPosts();
        $this->view->render('page/header');

        $this->view->title = 'Title';

        $this->view->render('posts/posts');
        $this->view->render('page/footer');
    }

    public function show(){
        echo 'Rodom tik viena posta';
    }
}