<hr>
<footer>Mano footeris</footer>

</body>
</html>