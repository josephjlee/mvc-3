<?php

namespace Core;

class View
{

    // public $title;

    public function render($template){

        include '/Users/kabalas/pamoka1/views/'.$template.'.php';

    }
}