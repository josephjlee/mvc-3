<?php

namespace App\Model;

use Core\Database;

class PostsModel
{

    public function getPosts(){
        $db = new Database();
        $db->select()->from('posts');
        return $db->get();
    }

    public function getPost($id){

    }


}