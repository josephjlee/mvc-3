<?php

namespace Core;

class Database
{

    private $pdo;
    private $sql = '';

    public function connect(){
        $pdo = null;
        try {
            $pdo = new \PDO('mysql:host=127.0.0.1;dbname=pdo2', 'newuser', 'password');

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
        }

        $this->pdo =  $pdo;
    }

    public function select($fields = '*'){
        $this->sql .= 'SELECT '.$fields;
        return $this;
    }

    public function from($table){
        $this->sql .= ' FROM '.$table;
        return $this;
    }


    public function get(){
        $this->connect();
        $sql = $this->sql;
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        $user = $stmt->fetch();
        return $user;
    }
}


