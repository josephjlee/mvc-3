<html>
<body>
<header>
    <nav>
        <ul>
            <li>
                <a href="/">Home</a>
            </li>
        </ul>
    </nav>
</header>
<hr>
